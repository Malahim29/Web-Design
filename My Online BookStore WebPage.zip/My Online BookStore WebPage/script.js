let menuBtn = document.querySelector('#menu-btn');
let navbar = document.querySelector('.header .flex .nabvar');

menuBtn.onclick = () =>{
    menuBtn.classList.toggle('fa-times');
    navbar.classList.toggle('active');
}

const carousel = document.querySelector(".carousel");

let isDragging = false;

const dragStart = () => {
    isDragging = true;
    carousel.classList.add("dragging");
}

const dragging = (e) => {
    if(!isDragging) return;
    carousel.scrollLeft = e.pageX;
}

carousel.addEventListener("mousemove", dragging);
carousel.addEventListener("mousemove", dragging);